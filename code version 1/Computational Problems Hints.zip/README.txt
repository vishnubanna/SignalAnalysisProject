Both files contain the same content. 
You will need Adobe Flash installed on your PC to view the video clips in the PDF file. 